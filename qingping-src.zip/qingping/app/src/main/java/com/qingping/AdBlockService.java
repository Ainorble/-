package com.qingping;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Locale;

/**
 * 核心服务。
 * 1. 开屏广告：出现“跳过/关闭广告”按钮，且页面有广告标识、倒计时数字或开屏类名之一时，自动点击跳过。
 * 2. 误触跳转：用户刚点击了带广告标识的页面，2 秒内弹出其他应用的页面，则自动返回并计数。
 * 以上均为基于界面文字的启发式规则，关键词见下方常量。
 */
public class AdBlockService extends AccessibilityService {

    private static final String[] SKIP_WORDS = {"跳过", "关闭广告", "skip", "close ad"};
    private static final String[] AD_WORDS = {"广告", "sponsored", "advertisement"};
    private static final String[] AD_CLASS_HINTS = {"splash", "adactivity", "advert"};

    private static final int MAX_SKIP_LABEL_LEN = 12;
    private static final long SCAN_INTERVAL_MS = 300;
    private static final long SKIP_COOLDOWN_MS = 1000;
    private static final long REDIRECT_WINDOW_MS = 2000;

    private long lastScanTime;
    private long lastSkipTime;
    private String adClickPkg;
    private long adClickTime;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        // 无障碍服务是系统托管的，连接后顺便拉起前台保活服务
        try {
            startForegroundService(new Intent(this, KeepAliveService.class));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (pkg.equals(getPackageName())) return;

        switch (event.getEventType()) {
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                rememberAdClick(pkg);
                break;
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                if (blockRedirect(pkg)) return;
                trySkipSplash(pkg, event);
                break;
            case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
                trySkipSplash(pkg, event);
                break;
            default:
                break;
        }
    }

    @Override
    public void onInterrupt() {
    }

    // ---------- 开屏跳过 ----------

    private void trySkipSplash(String pkg, AccessibilityEvent event) {
        long now = System.currentTimeMillis();
        if (now - lastScanTime < SCAN_INTERVAL_MS) return;   // 节流：视频播放时事件很频繁
        lastScanTime = now;
        if (now - lastSkipTime < SKIP_COOLDOWN_MS) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            AccessibilityNodeInfo skip = findSkipNode(root);
            if (skip == null) return;
            try {
                boolean adContext = classLooksLikeAd(event.getClassName())
                        || hasDigit(textOf(skip))    // “跳过 3”这种倒计时几乎只出现在开屏
                        || hasAdLabel(root);
                if (!adContext) return;

                lastSkipTime = now;
                clickNode(skip);
                StatsStore.increment(this, pkg, "splash");
            } finally {
                skip.recycle();
            }
        } finally {
            root.recycle();
        }
    }

    private AccessibilityNodeInfo findSkipNode(AccessibilityNodeInfo root) {
        for (String word : SKIP_WORDS) {
            List<AccessibilityNodeInfo> hits = root.findAccessibilityNodeInfosByText(word);
            if (hits == null) continue;
            AccessibilityNodeInfo found = null;
            for (AccessibilityNodeInfo n : hits) {
                if (found == null && textOf(n).length() <= MAX_SKIP_LABEL_LEN) {
                    found = n;
                } else {
                    n.recycle();
                }
            }
            if (found != null) return found;
        }
        return null;
    }

    private void clickNode(AccessibilityNodeInfo node) {
        if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return;
        // 控件本身不可点击时，手势点击它的中心位置（需要 canPerformGestures）
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        Path path = new Path();
        path.moveTo(r.centerX(), r.centerY());
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 50))
                .build();
        dispatchGesture(gesture, null, null);
    }

    // ---------- 误触跳转 ----------

    private void rememberAdClick(String pkg) {
        if (!StatsStore.isRedirectOn(this)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            if (hasAdLabel(root)) {
                adClickPkg = pkg;
                adClickTime = System.currentTimeMillis();
            }
        } finally {
            root.recycle();
        }
    }

    /** 返回 true 表示已拦截并执行了返回。 */
    private boolean blockRedirect(String pkg) {
        if (adClickPkg == null) return false;
        if (System.currentTimeMillis() - adClickTime > REDIRECT_WINDOW_MS) {
            adClickPkg = null;
            return false;
        }
        if (pkg.equals(adClickPkg)) return false;   // 同一应用内的页面切换不管

        String host = adClickPkg;
        adClickPkg = null;
        performGlobalAction(GLOBAL_ACTION_BACK);
        StatsStore.increment(this, host, "redirect");
        return true;
    }

    // ---------- 工具方法 ----------

    private boolean hasAdLabel(AccessibilityNodeInfo root) {
        for (String word : AD_WORDS) {
            List<AccessibilityNodeInfo> hits = root.findAccessibilityNodeInfosByText(word);
            if (hits != null && !hits.isEmpty()) {
                for (AccessibilityNodeInfo n : hits) n.recycle();
                return true;
            }
        }
        return false;
    }

    private static boolean classLooksLikeAd(CharSequence cls) {
        if (cls == null) return false;
        String c = cls.toString().toLowerCase(Locale.ROOT);
        for (String hint : AD_CLASS_HINTS) {
            if (c.contains(hint)) return true;
        }
        return false;
    }

    private static boolean hasDigit(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (Character.isDigit(s.charAt(i))) return true;
        }
        return false;
    }

    private static String textOf(AccessibilityNodeInfo n) {
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) t = n.getContentDescription();
        return t == null ? "" : t.toString();
    }
}
