package com.qingping;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/** 按应用统计拦截次数，数据保存在本机 SharedPreferences，重启不丢失。 */
public final class StatsStore {

    private static final String PREFS = "qingping";
    private static final String KEY_REDIRECT_ON = "redirect_on";

    private StatsStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** kind: "splash"（开屏跳过）或 "redirect"（误触跳转拦截） */
    public static synchronized void increment(Context c, String pkg, String kind) {
        SharedPreferences sp = prefs(c);
        String key = kind + ":" + pkg;
        sp.edit().putInt(key, sp.getInt(key, 0) + 1).apply();
    }

    /** 返回 包名 -> {开屏次数, 跳转次数} */
    public static synchronized Map<String, int[]> load(Context c) {
        Map<String, int[]> out = new HashMap<>();
        for (Map.Entry<String, ?> e : prefs(c).getAll().entrySet()) {
            if (!(e.getValue() instanceof Integer)) continue;
            String key = e.getKey();
            int sep = key.indexOf(':');
            if (sep < 0) continue;
            String kind = key.substring(0, sep);
            String pkg = key.substring(sep + 1);
            int[] arr = out.get(pkg);
            if (arr == null) {
                arr = new int[2];
                out.put(pkg, arr);
            }
            int n = (Integer) e.getValue();
            if ("splash".equals(kind)) arr[0] += n;
            else if ("redirect".equals(kind)) arr[1] += n;
        }
        return out;
    }

    public static synchronized void clear(Context c) {
        SharedPreferences sp = prefs(c);
        SharedPreferences.Editor ed = sp.edit();
        for (String key : sp.getAll().keySet()) {
            if (key.contains(":")) ed.remove(key);
        }
        ed.apply();
    }

    public static boolean isRedirectOn(Context c) {
        return prefs(c).getBoolean(KEY_REDIRECT_ON, true);
    }

    public static void setRedirectOn(Context c, boolean on) {
        prefs(c).edit().putBoolean(KEY_REDIRECT_ON, on).apply();
    }
}
