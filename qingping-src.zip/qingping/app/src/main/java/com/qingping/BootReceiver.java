package com.qingping;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 开机后拉起保活服务。无障碍服务本身由系统在开机后自动重新绑定。 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            context.startForegroundService(new Intent(context, KeepAliveService.class));
        } catch (Exception ignored) {
            // 个别系统会在开机广播中限制后台启动，之后无障碍服务连接时会再次拉起
        }
    }
}
