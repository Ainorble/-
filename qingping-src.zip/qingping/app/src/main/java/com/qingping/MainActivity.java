package com.qingping;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    private TextView statusView;
    private TextView totalView;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);

        statusView = text(16, true);
        root.addView(statusView);

        root.addView(button("1. 开启无障碍权限",
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("2. 后台/自启动设置", v -> openAppDetails()));

        CheckBox redirect = new CheckBox(this);
        redirect.setText("拦截误触跳转广告");
        redirect.setChecked(StatsStore.isRedirectOn(this));
        redirect.setOnCheckedChangeListener((b, on) -> StatsStore.setRedirectOn(this, on));
        root.addView(redirect);

        totalView = text(15, false);
        root.addView(totalView);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(button("清空统计", v -> {
            StatsStore.clear(this);
            refresh();
        }));

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        startKeepAlive();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        statusView.setText(isAccessibilityOn()
                ? "状态：运行中（无障碍已开启）"
                : "状态：未开启，请先完成第 1 步");

        Map<String, int[]> stats = StatsStore.load(this);
        List<Map.Entry<String, int[]>> entries = new ArrayList<>(stats.entrySet());
        entries.sort((a, b) ->
                (b.getValue()[0] + b.getValue()[1]) - (a.getValue()[0] + a.getValue()[1]));

        int totalSplash = 0;
        int totalRedirect = 0;
        adapter.clear();
        for (Map.Entry<String, int[]> e : entries) {
            int[] c = e.getValue();
            totalSplash += c[0];
            totalRedirect += c[1];
            adapter.add(appLabel(e.getKey()) + "\n" + e.getKey()
                    + "\n开屏 " + c[0] + " 次 · 跳转 " + c[1] + " 次");
        }
        if (entries.isEmpty()) adapter.add("暂无拦截记录");

        totalView.setText("累计：开屏拦截 " + totalSplash + " 次，误触跳转拦截 " + totalRedirect + " 次");
    }

    private boolean isAccessibilityOn() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.contains(
                new ComponentName(this, AdBlockService.class).flattenToString());
    }

    private String appLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return ai.loadLabel(pm).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return pkg;
        }
    }

    private void startKeepAlive() {
        try {
            startForegroundService(new Intent(this, KeepAliveService.class));
        } catch (Exception e) {
            Toast.makeText(this, "保活服务启动失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openAppDetails() {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
        Toast.makeText(this, "请把电池设为“不受限制”，并开启自启动与后台运行",
                Toast.LENGTH_LONG).show();
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(listener);
        return b;
    }

    private TextView text(int sp, boolean bold) {
        TextView tv = new TextView(this);
        tv.setTextSize(sp);
        tv.setPadding(0, dp(8), 0, dp(8));
        if (bold) tv.setTypeface(null, Typeface.BOLD);
        return tv;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
