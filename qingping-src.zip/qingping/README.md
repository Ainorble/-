# 清屏 (QingPing)

拦截其他应用的开屏广告（自动点击“跳过”）和误触跳转广告（自动返回），按应用统计次数。
纯本地运行，没有网络权限，不收集任何数据。

## 一、打包 APK（Android Studio，约 5 分钟）

1. File → New → New Project → **Empty Views Activity**，Language 选 **Java**，
   Minimum SDK 选 **26**，包名填 `com.qingping`。
2. 把本压缩包 `app/src/main/` 下的内容覆盖到新工程的同名位置：
   - `AndroidManifest.xml`
   - `java/com/qingping/*.java`（5 个文件，覆盖模板的 MainActivity）
   - `res/xml/accessibility_config.xml`
   - `res/values/strings.xml`
3. Build → Build App Bundle(s) / APK(s) → Build APK(s)。
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`，传到手机安装。

## 二、首次使用

1. 打开“清屏” → 点“1. 开启无障碍权限” → 找到“清屏”并开启。
   - Android 13+ 若提示“受限制的设置”：设置 → 应用 → 清屏 → 右上角 ⋮ → **允许受限制的设置**，然后再开启无障碍。
2. 点“2. 后台/自启动设置”，把电池设为“不受限制”，开启自启动（各品牌名称不同，如 MIUI/HyperOS 的“自启动”、ColorOS 的“允许自启动”、EMUI 的“应用启动管理”）。
3. 在最近任务里对“清屏”下拉，选择“锁定”（部分系统叫“加锁”），可降低被清理的概率。
4. 打开几个有开屏广告的应用验证效果，回到“清屏”查看统计。

## 三、可调参数（AdBlockService.java 顶部）

- `SKIP_WORDS`：跳过按钮的关键词
- `AD_WORDS`：广告标识的关键词
- `AD_CLASS_HINTS`：开屏页类名关键词
- `REDIRECT_WINDOW_MS`：广告点击后判定为误触跳转的时间窗口（默认 2 秒）

## 四、已知限制

- 只能处理界面上可见的控件；网络层广告、自绘界面（游戏、部分 Flutter/Unity 页面）无法识别。
- 没有文字的跳过按钮只能按坐标点击，可能误点。
- 误触跳转为启发式判断，可能误伤正常的跨应用跳转，可在界面上关闭。
- 强制停止应用或部分国产系统的省电策略会终止服务，需按第二节设置。
- 无障碍类应用通常无法通过应用商店审核，建议仅自用。

## 五、只用手机打包（GitHub Actions）

1. 注册 GitHub（github.com），新建仓库，名字随意（如 qingping）。
2. 进入仓库，点 Add file → Upload files，选择 `qingping-src.zip` 上传并提交。
3. 再点 Add file → Create new file，文件名填 `.github/workflows/build.yml`（输入斜杠会自动建文件夹），
   内容粘贴为 README 末尾“附：build.yml”的内容，提交。
4. 点顶部 Actions，等待 “Build APK” 运行完成（约 5–10 分钟）。
5. 进入该次运行，页面底部 Artifacts 中下载 `qingping-apk`，解压得到 `app-debug.apk`，安装即可
   （需允许安装未知应用；Android 13+ 若提示受限，见第二节）。

附：build.yml

    name: Build APK
    on:
      push:
        paths:
          - 'qingping-src.zip'
          - '.github/workflows/build.yml'
      workflow_dispatch:
    jobs:
      build:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - name: 解压工程
            run: unzip -q qingping-src.zip -d src
          - uses: actions/setup-java@v4
            with:
              distribution: temurin
              java-version: '17'
          - name: 安装 SDK 组件
            run: |
              SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
              yes | "$SDKM" --licenses > /dev/null || true
              "$SDKM" "platforms;android-34" "build-tools;34.0.0"
          - uses: gradle/actions/setup-gradle@v4
            with:
              gradle-version: '8.7'
          - name: 编译 Debug APK
            working-directory: src/qingping
            run: gradle assembleDebug --no-daemon
          - uses: actions/upload-artifact@v4
            with:
              name: qingping-apk
              path: src/qingping/app/build/outputs/apk/debug/app-debug.apk
